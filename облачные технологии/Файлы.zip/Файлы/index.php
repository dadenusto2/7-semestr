<!DOCTYPE html>
<html>
 <head>
   <title>Автомобили</title>
   <meta charset="utf-8">
   <link href="styles.css" rel="stylesheet">
 </head>
 <body>
<?php $servername = "localhost";
$username = "oot_user";
$password = "1";
$dbname = "oot";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  echo "Connection failed: " . $conn->connect_error;
}
$sql = "SELECT * FROM cars";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    echo "<table>
    <tr><th>id</th><th>название</th><th>0-100</th><th>длина</th></tr>";
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "<tr>
    <td>". $row["id"] . "</td><td>" . $row["name"] . "</td><td>" . $row["speed"] . "</td><td>" . $row["length"] . "</td>
    </tr>";
  }
  echo "</table>";
} else {
  echo "0 results";
}
$conn->close();
?>
 </body>