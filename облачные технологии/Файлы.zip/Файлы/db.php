<?php
$servername = "localhost";
$username = "oot_user";
$password = "1";
$dbname = "oot";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  echo "Connection failed: " . $conn->connect_error;
}