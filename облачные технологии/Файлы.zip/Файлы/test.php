<?php
$servername = "localhost";
$username = "oot_user";
$password = "1";
$dbname = "oot";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  echo "Connection failed: " . $conn->connect_error;
}
$sql = "SELECT * FROM cars";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table class=\"table_col\">
    <colgroup>
        <col style=\"background:#C7DAF0;\">
    </colgroup>";
    echo "<th><td>id</td><td>название</td><td>0-100</td><td>длина</td></th>";
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "<tr>
    <td>". $row["id"] . "</td><td><" . $row["name"] . "</td><td>" . $row["0-100"] . "</td><td>" . $row["length"] . "</td>;
    </tr>";
  }
  echo "</table>";
} else {
  echo "0 results";
}
$conn->close();
?>