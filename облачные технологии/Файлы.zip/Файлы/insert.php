<?php
include_once 'db.php';
if(isset($_POST['submit']))
{    
     $name = $_POST['name'];
     $speed = $_POST['speed'];
     $length = $_POST['length'];
     $sql = "INSERT INTO cars (name,speed,length)
     VALUES ('$name',$speed,$length)";
     if (mysqli_query($conn, $sql)) {
        echo "New record has been added successfully !";
     } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
     }
     mysqli_close($conn);
}
?>